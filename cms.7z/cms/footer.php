<table width="100%" border="0" cellspacing="0" cellpadding="0" class=" bottomBg">
<tr>
    <td height="70" align="center" class="hui">
	  Copyright(C)2009 <a href="http://www.test.com" class="hui12" target="_blank">test.com</a>  All Rights Reserved <br />
      邮箱：root@test.com<br /></td>
 </tr>
</table>
</div>
</body>
</html>